package com.example.quizapplication

import android.os.Parcel
import android.os.Parcelable

class Question : Parcelable
{
//    Getters and Setters
    var question: String? = null
    var option1: String? = null
    var option2: String? = null
    var option3: String? = null
    var option4: String? = null
    var answerNr = 0
    var difficulty: String? = null

    constructor() {}
    constructor(
        question: String?,
        option1: String?,
        option2: String?,
        option3: String?,
        option4: String?,
        answerNr: Int,
        difficulty: String?
    )
    {
        this.question = question
        this.option1 = option1
        this.option2 = option2
        this.option3 = option3
        this.option4 = option4
        this.answerNr = answerNr
        this.difficulty = difficulty
    }

    protected constructor(`in`: Parcel)
    {
        question = `in`.readString()
        option1 = `in`.readString()
        option2 = `in`.readString()
        option3 = `in`.readString()
        option4 = `in`.readString()
        answerNr = `in`.readInt()
        difficulty = `in`.readString()
    }

    override fun writeToParcel(dest: Parcel, flags: Int)
    {
        dest.writeString(question)
        dest.writeString(option1)
        dest.writeString(option2)
        dest.writeString(option3)
        dest.writeString(option4)
        dest.writeInt(answerNr)
        dest.writeString(difficulty)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object
    {
        const val DIFFICULTY_EASY = "Easy"
        const val DIFFICULTY_MEDIUM = "Medium"
        const val DIFFICULTY_HARD = "Hard"
        val CREATOR: Parcelable.Creator<Question?> = object : Parcelable.Creator<Question?>
        {
            override fun createFromParcel(`in`: Parcel): Question? {
                return Question(`in`)
            }
            override fun newArray(size: Int): Array<Question?>
            {
                return arrayOfNulls(size)
            }
        }

        val allDifficultyLevels: Array<String>
            get() = arrayOf(
                DIFFICULTY_EASY,
                DIFFICULTY_MEDIUM,
                DIFFICULTY_HARD
            )
    }
}

