package com.example.quizapplication

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class QuizActivity : AppCompatActivity()
{
    private var textViewQuestion: TextView? = null
    private var textViewScore: TextView? = null
    private var textViewQuestionCount: TextView? = null
    lateinit var textViewDifficulty: TextView
    lateinit var textViewCountDown: TextView
    private var rbGroup: RadioGroup? = null
    lateinit var rb1: RadioButton
    lateinit var rb2: RadioButton
    lateinit var rb3: RadioButton
    lateinit var rb4: RadioButton
    lateinit var buttonConfirmNext: Button
    private var textColorDefaultRb: ColorStateList? = null
    private var textColorDefaultCd: ColorStateList? = null
    private var countDownTimer: CountDownTimer? = null
    private var timeLeftInMillis: Long = 0
    lateinit var questionList: ArrayList<Question>
    private var questionCounter = 0
    private var questionCountTotal = 0
    private var currentQuestion: Question? = null
    private var score = 0
    private var answered = false
    private var backPressedTime: Long = 0

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        textViewQuestion = findViewById(R.id.text_view_question)
        textViewScore = findViewById(R.id.text_view_score)
        textViewQuestionCount = findViewById(R.id.text_view_question_count)
        textViewDifficulty = findViewById(R.id.text_view_difficulty)
        textViewCountDown = findViewById(R.id.text_view_countdown)

        rbGroup = findViewById(R.id.radio_group)
        rb1 = findViewById(R.id.radio_button1)
        rb2 = findViewById(R.id.radio_button2)
        rb3 = findViewById(R.id.radio_button3)
        rb4 = findViewById(R.id.radio_button4)

        buttonConfirmNext = findViewById(R.id.button_confirm_next)
        textColorDefaultCd = textViewCountDown.getHintTextColors()
        textColorDefaultRb = rb1.getTextColors()

        val intent = intent
        val difficulty =
            intent.getStringExtra(StartingScreenActivity.EXTRA_DIFFICULTY)

        textViewDifficulty.setText("Difficulty : $difficulty")

        if (savedInstanceState == null)
        {
            val dbHelper = QuizDbHelper(this)
            questionList = dbHelper.getQuestions(difficulty)
            questionCountTotal = questionList.size
            Collections.shuffle(questionList)
            showNextQuestion()
        }
        else
        {
            questionList = savedInstanceState.getParcelableArrayList(KEY_QUESTION_LIST)!!
            questionCountTotal = questionList!!.size
            questionCounter = savedInstanceState.getInt(KEY_QUESTION_COUNT)
            currentQuestion = questionList!![questionCounter - 1]
            score = savedInstanceState.getInt(KEY_SCORE)
            timeLeftInMillis = savedInstanceState.getLong(KEY_MILLIS_LEFT)
            answered = savedInstanceState.getBoolean(KEY_ANSWERED)
            if (!answered)
            {
                startCountDown()
            } else
            {
                updateCountDownText()
                showSolution()
            }
        }

        buttonConfirmNext.setOnClickListener(View.OnClickListener
        {
            if (!answered)
            {
                if (rb1.isChecked() || rb2.isChecked() || rb3.isChecked() || rb4.isChecked())
                {
                    checkAnswer()
                }
                else
                {
                    Toast.makeText(
                        this@QuizActivity,
                        "Please Select And Answer",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            else
            {
                showNextQuestion()
            }
        })
    }

    private fun showNextQuestion()
    {
        rb1!!.setTextColor(textColorDefaultRb)
        rb2!!.setTextColor(textColorDefaultRb)
        rb3!!.setTextColor(textColorDefaultRb)
        rb4!!.setTextColor(textColorDefaultRb)
        rbGroup!!.clearCheck()

        if (questionCounter < questionCountTotal)
        {
            currentQuestion = questionList!![questionCounter]
            textViewQuestion!!.text = currentQuestion!!.question
            rb1!!.text = currentQuestion!!.option1
            rb2!!.text = currentQuestion!!.option2
            rb3!!.text = currentQuestion!!.option3
            rb4!!.text = currentQuestion!!.option4
            questionCounter++
            textViewQuestionCount!!.text = "Question : $questionCounter/$questionCountTotal"
            answered = false
            buttonConfirmNext!!.text = "Confirm"
            timeLeftInMillis = COUNTDOWN_IN_MILLIS
            startCountDown()
        }
        else
        {
            finishQuiz()
        }
    }

    private fun startCountDown()
    {
        countDownTimer = object : CountDownTimer(timeLeftInMillis, 1000)
        {
            override fun onTick(millisUntilFinished: Long)
            {
                timeLeftInMillis = millisUntilFinished
                updateCountDownText()
            }

            override fun onFinish()
            {
                timeLeftInMillis = 0
                updateCountDownText()
                checkAnswer()
            }
        }.start()
    }

    private fun updateCountDownText()
    {
        val minutes = (timeLeftInMillis / 1000).toInt() / 60
        val seconds = (timeLeftInMillis / 1000).toInt() % 60
        val timeFormated = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)

        textViewCountDown!!.text = timeFormated

        if (timeLeftInMillis < 10000)
        {
            textViewCountDown!!.setTextColor(Color.RED)
        }
        else
        {
            textViewCountDown!!.setTextColor(textColorDefaultCd)
        }
    }

    private fun checkAnswer()
    {
        answered = true
        countDownTimer!!.cancel()

        val rbSelected = findViewById<RadioButton>(rbGroup!!.checkedRadioButtonId)
        val answerNr = rbGroup!!.indexOfChild(rbSelected) + 1

        if (answerNr == currentQuestion!!.answerNr)
        {
            score++
            textViewScore!!.text = "Score : $score"
        }
        showSolution()
    }

    private fun showSolution()
    {
        rb1!!.setTextColor(Color.RED)
        rb2!!.setTextColor(Color.RED)
        rb3!!.setTextColor(Color.RED)
        rb4!!.setTextColor(Color.RED)
        when (currentQuestion!!.answerNr)
        {
            1 -> {
                rb1!!.setTextColor(Color.GREEN)
                textViewQuestion!!.text = "Option 1 Is Correct"
            }
            2 -> {
                rb2!!.setTextColor(Color.GREEN)
                textViewQuestion!!.text = "Option 2 Is Correct"
            }
            3 -> {
                rb3!!.setTextColor(Color.GREEN)
                textViewQuestion!!.text = "Option 3 Is Correct"
            }
            4 -> {
                rb4!!.setTextColor(Color.GREEN)
                textViewQuestion!!.text = "Option 4 Is Correct"
            }
        }
        if (questionCounter < questionCountTotal) {
            buttonConfirmNext!!.text = "Next"
        } else {
            buttonConfirmNext!!.text = "Finish"
        }
    }

    private fun finishQuiz()
    {
        val resultIntent = Intent()
        resultIntent.putExtra(EXTRA_SCORE, score)
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    override fun onBackPressed()
    {
        if (backPressedTime + 2000 > System.currentTimeMillis())
        {
            finishQuiz()
        } else {
            Toast.makeText(this, "Press Back Again To Finish", Toast.LENGTH_SHORT).show()
        }
        backPressedTime = System.currentTimeMillis()
    }

    override fun onDestroy()
    {
        super.onDestroy()
        if (countDownTimer != null)
        {
            countDownTimer!!.cancel()
        }
    }

    override fun onSaveInstanceState(outState: Bundle)
    {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_SCORE, score)
        outState.putInt(KEY_QUESTION_COUNT, questionCounter)
        outState.putLong(KEY_MILLIS_LEFT, timeLeftInMillis)
        outState.putBoolean(KEY_ANSWERED, answered)
        outState.putParcelableArrayList(KEY_QUESTION_LIST, questionList)
    }

    companion object
    {
        const val EXTRA_SCORE = "extraScore"
        private const val COUNTDOWN_IN_MILLIS: Long = 30000
        private const val KEY_SCORE = "keyScore"
        private const val KEY_QUESTION_COUNT = "keyQuestionCount"
        private const val KEY_MILLIS_LEFT = "keyMillisLeft"
        private const val KEY_ANSWERED = "keyAnswered"
        private const val KEY_QUESTION_LIST = "keyQuestionList"
    }
}