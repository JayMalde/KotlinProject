package com.example.quizapplication

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StartingScreenActivity : AppCompatActivity()
{
    lateinit var textViewHighscore: TextView
    lateinit var spinnerDifficulty: Spinner
    private var highscore = 0

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_starting_screen)

        textViewHighscore = findViewById(R.id.text_view_highscore)
        spinnerDifficulty = findViewById(R.id.spinner_difficulty)

        val difficultyLevels: Array<String> = Question.allDifficultyLevels
        val adapterDifficulty = ArrayAdapter(this, android.R.layout.simple_spinner_item, difficultyLevels)

        adapterDifficulty.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerDifficulty.setAdapter(adapterDifficulty)

        loadHighscore()

        val buttonStartQuiz = findViewById<Button>(R.id.button_start_quiz)
        buttonStartQuiz.setOnClickListener { startQuiz() }
    }

    private fun startQuiz()
    {
        val difficulty = spinnerDifficulty!!.selectedItem.toString()
        val intent = Intent(this@StartingScreenActivity, QuizActivity::class.java)
        intent.putExtra(EXTRA_DIFFICULTY, difficulty)
        startActivityForResult(intent, REQUEST_CODE_QUIZ)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?)
    {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_QUIZ)
        {
            if (resultCode == Activity.RESULT_OK)
            {
                val score = data!!.getIntExtra(QuizActivity.EXTRA_SCORE, 0)
                if (score > highscore)
                {
                    updateHighscore(score)
                }
            }
        }
    }

    private fun loadHighscore()
    {
        val prefs = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE)

        highscore = prefs.getInt(KEY_HIGHSCORE, 0)
        textViewHighscore!!.text = "Highscore : $highscore"
    }

    private fun updateHighscore(highscoreNew: Int)
    {
        highscore = highscoreNew
        textViewHighscore!!.text = "Highscore : $highscore"

        val prefs = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE)
        val editor = prefs.edit()

        editor.putInt(KEY_HIGHSCORE, highscore)
        editor.apply()
    }

    companion object
    {
        private const val REQUEST_CODE_QUIZ = 1
        const val EXTRA_DIFFICULTY = "extraDifficulty"
        const val SHARED_PREFS = "sharedPrefs"
        const val KEY_HIGHSCORE = "keyHighscore"
    }
}