package com.example.quizapplication

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.quizapplication.QuizContract.QuestionsTable
import java.util.*

class QuizDbHelper(context: Context?) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION)
{
    lateinit var db: SQLiteDatabase
    override fun onCreate(db: SQLiteDatabase)
    {
        this.db = db
        val SQL_CREATE_QUESTIONS_TABLE = " CREATE TABLE " +
                QuestionsTable.TABLE_NAME + " ( " +
                QuestionsTable.ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT ," +
                QuestionsTable.COLUMN_OPTION1 + " TEXT ," +
                QuestionsTable.COLUMN_OPTION2 + " TEXT ," +
                QuestionsTable.COLUMN_OPTION3 + " TEXT ," +
                QuestionsTable.COLUMN_OPTION4 + " TEXT ," +
                QuestionsTable.COLUMN_ANSWER_NR + " INTEGER, " +
                QuestionsTable.COLUMN_DIFFICULTY + " TEXT" +
                ")"
        db.execSQL(SQL_CREATE_QUESTIONS_TABLE)
        fillQuestionsTable()
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int)
    {
        db.execSQL("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME)
        onCreate(db)
    }

    private fun fillQuestionsTable()
    {
        val q1 = Question("Which Organization Created Kotlin Programming Language", "A : JetBrains", "B : Google", "C : Microsoft", "D : Apache", 1, Question.DIFFICULTY_EASY)
        addQuestion(q1)
        val q2 = Question("Which Was The Problem That Was Solved By Kotlin That Caused Lots Of Crashes and Lossed", "A : Null Pointer Exceptions", "B : IO Error", "C : Page Not Found", "D : Database Exceptions", 1, Question.DIFFICULTY_EASY)
        addQuestion(q2)
        val q3 = Question("When Was Kotlin Version 1.0 was Launched", "A : 2012", "B : 2015", "C : 2015", "D : 2016", 4, Question.DIFFICULTY_MEDIUM)
        addQuestion(q3)
        val q4 = Question("When Was Kotlin Announced as Preferred Language for Android Developement", "A : 2016", "B : 2015", "C : 2019", "D : 2017",  3, Question.DIFFICULTY_MEDIUM)
        addQuestion(q4)
        val q5 = Question("Which of The Feature Is Not In Kotlin Programming Language", "A : Coroutines", "B : Dynamically typed", "C : Null safety", "D : Expressiveness", 2, Question.DIFFICULTY_HARD)
        addQuestion(q5)
        val q6 = Question("What Java Has and Kotlin Does Not", "A : Ternary Operator", "B : Checked Exceptions", "C : Non Primitive Fields", "D : Smart Casts", 4, Question.DIFFICULTY_HARD)
        addQuestion(q6)
    }

    private fun addQuestion(question: Question)
    {
        val cv = ContentValues()
        cv.put(QuestionsTable.COLUMN_QUESTION, question.question)
        cv.put(QuestionsTable.COLUMN_OPTION1, question.option1)
        cv.put(QuestionsTable.COLUMN_OPTION2, question.option2)
        cv.put(QuestionsTable.COLUMN_OPTION3, question.option3)
        cv.put(QuestionsTable.COLUMN_OPTION4, question.option4)
        cv.put(QuestionsTable.COLUMN_ANSWER_NR, question.answerNr)
        cv.put(QuestionsTable.COLUMN_DIFFICULTY, question.difficulty)
        db!!.insert(QuestionsTable.TABLE_NAME, null, cv)
    }

    val allQuestions: ArrayList<Question>
        get()
        {
            val questionList = ArrayList<Question>()
            db = readableDatabase
            val c =
                db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME, null)
            if (c.moveToFirst())
            {
                do {
                    val question = Question()
                    question.question = c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION))
                    question.option1 = c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1))
                    question.option2 = c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2))
                    question.option3 = c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3))
                    question.option4 = c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4))
                    question.answerNr = c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR))
                    question.difficulty =
                        c.getString(c.getColumnIndex(QuestionsTable.COLUMN_DIFFICULTY))
                    questionList.add(question)
                } while (c.moveToNext())
            }
            c.close()
            return questionList
        }

    fun getQuestions(difficulty: String): ArrayList<Question>
    {
        val questionList = ArrayList<Question>()
        db = readableDatabase
        val selectionArgs = arrayOf(difficulty)
        val c = db.rawQuery(
            "SELECT * FROM " + QuestionsTable.TABLE_NAME + " WHERE " + QuestionsTable.COLUMN_DIFFICULTY + " = ?",
            selectionArgs
        )
        if (c.moveToFirst())
        {
            do {
                val question = Question()
                question.question = c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION))
                question.option1 = c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1))
                question.option2 = c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2))
                question.option3 = c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3))
                question.option4 = c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4))
                question.answerNr = c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR))
                question.difficulty = c.getString(c.getColumnIndex(QuestionsTable.COLUMN_DIFFICULTY))
                questionList.add(question)
            } while (c.moveToNext())
        }
        c.close()
        return questionList
    }

    companion object
    {
        private const val DATABASE_NAME = "MyQuiz.db"
        private const val DATABASE_VERSION = 1
    }
}